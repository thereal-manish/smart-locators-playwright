from smart_locators_playwright.smart_locators import SmartLocators

__version__="0.0.1"

### Initialize all alias here explicitly
__all__ = [
    "SmartLocators"
]